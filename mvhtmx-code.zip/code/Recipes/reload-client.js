/***
 * Excerpted from "Server-Driven Web Apps with htmx",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit https://pragprog.com/titles/mvhtmx for more book information.
***/
const ws = new WebSocket('ws://localhost:3001');

ws.addEventListener('close', event => {
  // This assumes the server will restart and create a new WebSocket server.
  setTimeout(() => {
    location.reload();
  }, 500);
});

ws.addEventListener('message', event => {
  if (event.data === 'reload') location.reload();
});
