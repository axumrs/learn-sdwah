import {type Context, Hono} from 'hono';
import {serveStatic} from 'hono/bun';

let percentComplete = 0;
function ProgressBar() {
  return (
    <div
      id="progress-container"
      hx-get="/progress"
      hx-trigger={percentComplete < 100 ? 'load delay:1s' : ''}
      hx-swap="outerHTML"
      role="progressbar"
      aria-valuenow={percentComplete}
    >
      <div id="progress-text">{percentComplete.toFixed(1)}%</div>
      {/* This div MUST have an id in order for
          the CSS transition to work. */}
      <div id="progress-bar" style={`width: ${percentComplete}%`} />
    </div>
  );
}
const app = new Hono();

app.use('/*', serveStatic({root: './public'}));
app.get('/progress-bar', (c: Context) => c.html(<ProgressBar />));
app.get('/progress', (c: Context) => {
  const trigger = c.req.header('hx-trigger');
  if (trigger === 'reset-btn') {
    percentComplete = 0;
  } else {
    // Increase the progress by a random amount.
    const delta = Math.random() * 30;
    percentComplete = Math.min(100, percentComplete + delta);
  }
  return c.html(<ProgressBar />);
});

export default app;
