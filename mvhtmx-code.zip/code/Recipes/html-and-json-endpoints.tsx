function getAllTodos(): Todo[] {
  return getAllTodosQuery.all() as Todo[];
}
app.get('/todos/json', (c: Context) => {
  const todos = getAllTodos();
  return c.json(todos);
});
app.get('/todos', (c: Context) => {
  const todos = getAllTodos();

  const accept = c.req.header('accept');
  if (accept?.includes('application/json')) {
    return c.json(todos);
  }

  return c.html(
    <div id="todo-list">
      {todos.map(todo => (
        <TodoItem todo={todo} />
      ))}
    </div>
  );
});
