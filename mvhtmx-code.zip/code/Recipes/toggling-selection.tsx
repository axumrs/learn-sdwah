import {Context, Hono} from 'hono';
import {serveStatic} from 'hono/bun';

const dogs = ['Comet', 'Maisey', 'Oscar', 'Ramsay'];

let selectedName = '';
type DogProps = {name: string; toggle?: boolean};
function Dog({name, toggle}: DogProps) {
  const classes = 'dog' + (name === selectedName ? ' selected' : '');
  // We don't want this attributes for the initial renders.
  const attrs = toggle ? {'hx-swap-oob': 'true'} : {};
  return (
    <button class={classes} hx-get={`/toggle/${name}`} id={name} {...attrs}>
      {name}
    </button>
  );
}
const app = new Hono();

app.use('/*', serveStatic({root: './public'}));
app.get('/dogs', (c: Context) =>
  c.html(
    <>
      {dogs.map(dog => (
        <Dog name={dog} />
      ))}
    </>
  )
);
app.get('/toggle/:name', (c: Context) => {
  const name = c.req.param('name');
  const previousDog =
    selectedName ? <Dog name={selectedName} toggle /> : null;
  const thisDog = <Dog name={name} toggle />;

  // If the selected dog is clicked again, it is deselected.
  selectedName = name === selectedName ? '' : name;

  return c.html(
    <>
      {previousDog}
      {thisDog}
    </>
  );
});

export default app;
