import {Hono} from 'hono';
import {serveStatic} from 'hono/bun';

const app = new Hono();

app.use('/*', serveStatic({root: './public'}));
const wsServer = Bun.serve({
  port: 3001,
  fetch(req, server) {
    if (server.upgrade(req)) return; // no Response needed for success
    return new Response('WebSockets upgrade failed', {status: 500});
  },
  websocket: {
    open(ws) {
      console.log('WebSocket is open.');
    },
    message(ws, message) {
      console.log(`received "${message}"`);
      if (message === 'stop') {
        ws.close();
      } else {
        // A real app would send more useful messages and
        // might send more than one message over time.
        ws.send(`Thank you for sending "${message}".`);
      }
    },
    close(ws, code, message) {
      console.log('WebSocket closed with code', code);
      if (message) {
        console.log(`WebSocket closed with message "${message}"`);
      }
    }
  }
});
console.log('listening on port', wsServer.port);

export default app;
