import {type Context, Hono} from 'hono';
import {serveStatic} from 'hono/bun';
import {streamSSE} from 'hono/streaming';

const app = new Hono();

app.use('/*', serveStatic({root: './public'}));
let number = -1;

// This resets the number variable.
app.get('/start', (c: Context) => {
  number = Number(c.req.query('start'));
  return c.body(null);
});
app.get('/countdown', (c: Context) => {
  return streamSSE(c, async stream => {
    while (true) {
      if (number >= 0) {
        const jsx = <div>{number}</div>;
        await stream.writeSSE({
          event: 'count',
          id: String(crypto.randomUUID()),
          data: jsx.toString()
        });
        number--;
      }
      await stream.sleep(1000);
    }
  });
});

export default app;
