import {Hono} from 'hono';
import {serveStatic} from 'hono/bun';

const app = new Hono();

app.use('/*', serveStatic({root: './public'}));
const wsServer = Bun.serve({
  // The WebSocket port defaults to 3000 which conflicts with the HTTP server.
  port: 3001,
  fetch(req, server) {
    if (server.upgrade(req)) return; // no Response needed for success
    return new Response('WebSockets upgrade failed', {status: 500});
  },
  websocket: {
    message(ws, message: string) {
      try {
        const data = JSON.parse(message);
        // "start" is a form input name.
        countdown(ws, Number(data.start));
      } catch (e) {
        // This handles invalid JSON.
        console.error(e);
      }
    }
  }
});
async function countdown(ws: WebSocket, start: number) {
  let n = start;
  while (n >= 0) {
    // Using innerHTML for the first message
    // replaces all the previous content.
    const swap = n === start ? 'innerHTML' : 'beforeend';
    const html = (
      <div id="countdown" hx-swap-oob={swap}>
        <div>{n}</div>
      </div>
    );
    ws.send(html.toString());
    await Bun.sleep(1000);
    n--;
  }
}
console.log('listening on port', wsServer.port);

export default app;
