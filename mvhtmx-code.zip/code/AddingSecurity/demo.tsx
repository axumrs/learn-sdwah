import {type Context, Hono, type Next} from 'hono';
import {html} from 'hono/html';
import {serveStatic} from 'hono/bun';
const policies = [
  // This specifies where POST requests for violation reports will be sent.
  'report-uri /csp-report',

  // Only resources from the current domain are allowed
  // unless overridden by a more specific directive.
  "default-src 'self'",

  // This allows sending HTTP requests to the JSONPlaceholder API.
  // It also allows client-side JavaScript code to create a WebSocket.
  "connect-src 'self' https://jsonplaceholder.typicode.com ws:",

  // This allows getting Google fonts.
  // "link" tags for Google fonts have an href attribute
  // whose value begins with https://fonts.googleapis.com.
  // The linked font file contains @font-face CSS rules
  // with a src URL beginning with https://fonts.gstatic.com.
  'font-src https://fonts.googleapis.com https://fonts.gstatic.com',

  // This allows getting images from Unsplash.
  'img-src https://images.unsplash.com',

  // This allows getting videos from googleapis.
  'media-src http://commondatastorage.googleapis.com',

  // This allows downloading the htmx library from a CDN.
  "script-src-elem 'self' https://unpkg.com",

  // This allows the htmx library to insert style elements.
  "style-src-elem 'self' 'unsafe-inline' https://fonts.googleapis.com"
];

const csp = policies.join('; ');
const app = new Hono();

app.use('/*', (c: Context, next: Next) => {
  c.header('Content-Security-Policy', csp);

  const yearSeconds = 31536000;
  c.header(
    'Strict-Transport-Security',
    `max-age=${yearSeconds}; includeSubDomains`
  );

  const fn = serveStatic({root: './public'});
  return fn(c, next);
});
app.get('/dom-xss', (c: Context) => {
  return c.text("alert('A DOM XSS occurred!')");
});
app.get('/reflective-xss', (c: Context) => {
  return c.html("<script>alert('A reflective XSS occurred!');</script>");
});
app.get('/version', (c: Context) => {
  const storedContent = '<script>alert("XSS!");</script>';
  const escaped = html`v${Bun.version} ${storedContent}`;
  return c.html(escaped);
});
app.post('/csp-report', async (c: Context) => {
  const json = await c.req.json();
  const report = json['csp-report'];
  let file = report['document-uri'];
  if (file.endsWith('/')) file = 'index.html';
  console.error(
    `${file} attempted to access ${report['blocked-uri']} which ` +
      `violates the ${report['effective-directive']} CSP directive.`
  );
  c.status(403); // Forbidden
  return c.text('CSP violation');
});

export default app;
