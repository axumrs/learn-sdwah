app.use('/*', (c: Context, next: Next) => {
  c.header('Content-Security-Policy', csp);

  // Tell the browser that the site can only be accessed using HTTPS,
  // and that future attempts to access it using HTTP
  // should be automatically converted to HTTPS.
  const yearSeconds = 31536000;
  c.header(
    'Strict-Transport-Security',
    `max-age=${yearSeconds}; includeSubDomains`
  );

  const fn = serveStatic({root: './public'});
  return fn(c, next);
});
app.post('/csp-report', async (c: Context) => {
  const json = await c.req.json();
  const report = json['csp-report'];
  let file = report['document-uri'];
  const origin = c.req.raw.headers.get('origin');
  if (file === origin + '/') file = 'index.html';
  console.error(
    `${file} attempted to access ${report['blocked-uri']} which ` +
      `violates the ${report['effective-directive']} CSP directive.`
  );
  c.status(403); // Forbidden
  return c.text('CSP violation');
});
