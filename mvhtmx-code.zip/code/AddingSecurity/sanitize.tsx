import {type Context, Hono} from 'hono';
import sanitizeHtml from 'sanitize-html';

const app = new Hono();

app.post('/render', async (c: Context) => {
  const data = await c.req.formData();
  const markup = data.get('markup');
  return c.html(
    <section>
      <h2>Your Content<h2>
      {sanitizeHtml(markup)}
    </section>
  );
});
