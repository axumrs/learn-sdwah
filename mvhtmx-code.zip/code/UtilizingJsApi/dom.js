/***
 * Excerpted from "Server-Driven Web Apps with htmx",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit https://pragprog.com/titles/mvhtmx for more book information.
***/
const match = htmx.find(sel); // finds first match in document
const match = document.querySelector(sel); // DOM equivalent

const match = htmx.find(el, sel); // finds first match within el
const match = el.querySelector(sel); // DOM equivalent

const matches = htmx.findAll(sel); // finds all matches in document
const matches = document.querySelectorAll(sel); // DOM equivalent

const matches = htmx.findAll(el, sel); // finds all matches within el
const matches = el.querySelectorAll(sel); // DOM equivalent

// finds closest ancestor of element matching sel1 that matches sel2
const match = htmx.closest(sel1, sel2);
// finds closest matching ancestor of el that matches `sel`
const match = htmx.closest(el, sel);
const match = el.closest(sel); // DOM equivalent

htmx.remove(sel); // removes first matching element
htmx.remove(el); // removes element
el.remove(); // DOM equivalent
