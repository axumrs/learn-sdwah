/***
 * Excerpted from "Server-Driven Web Apps with htmx",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit https://pragprog.com/titles/mvhtmx for more book information.
***/
htmx.on(ev, cb);             // adds event listener to document.body
htmx.on(sel, ev, cb);        // adds event listener to element that matches sel
htmx.on(el, ev, cb);         // adds event listener to el
el.addEventListener(ev, cb); // DOM equivalent

htmx.off(ev, cb);      // removes event listener from document.body
htmx.off(sel, ev, cb); // removes event listener from the element
                       // that matches sel
htmx.off(el, ev, cb);  // removes event listener from el
el.removeEventListener(ev, cb); // DOM equivalent

htmx.trigger(sel, ev, detail);  // triggers event on the element
                                // that matches sel
htmx.trigger(el, ev, detail);   // triggers event on el
el.dispatchEvent(new CustomEvent(ev, detail)); // DOM equivalent
