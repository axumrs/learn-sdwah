/***
 * Excerpted from "Server-Driven Web Apps with htmx",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit https://pragprog.com/titles/mvhtmx for more book information.
***/
htmx.addClass(sel, cl);    // adds cl to element matching sel
htmx.addClass(el, cl);     // adds cl to el
el.classList.add(cl);      // DOM equivalent

htmx.removeClass(sel, cl); // removes cl from element matching sel
htmx.removeClass(el, cl);  // removes cl from el
el.classList.remove(cl);   // DOM equivalent

htmx.takeClass(sel, cl);   // adds cl to element matching sel and
                           // removes it from all siblings
htmx.takeClass(el, cl);    // adds cl to el and removes it from all siblings
                           // There is no simple DOM equivalent.

htmx.toggleClass(sel, cl); // toggles presence of cl on element matching sel
htmx.togglelass(el, cl);   // toggles presence of cl on el
el.classList.toggle(cl);   // DOM equivalent
